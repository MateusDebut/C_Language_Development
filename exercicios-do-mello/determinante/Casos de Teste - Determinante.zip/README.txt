Arquivo zip gerado em: 05/09/2023 01:25:01 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Determinante