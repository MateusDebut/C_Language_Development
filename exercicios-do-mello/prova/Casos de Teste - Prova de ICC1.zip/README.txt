Arquivo zip gerado em: 05/09/2023 01:27:22 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Prova de ICC1