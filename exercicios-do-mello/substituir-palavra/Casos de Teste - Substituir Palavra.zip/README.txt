Arquivo zip gerado em: 05/09/2023 01:23:52 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Substituir Palavra