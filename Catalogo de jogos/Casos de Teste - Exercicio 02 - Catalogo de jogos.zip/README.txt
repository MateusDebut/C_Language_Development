Arquivo zip gerado em: 18/09/2021 16:44:56 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 02 - Catálogo de jogos