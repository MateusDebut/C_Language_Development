#ifndef UTIL_H
#define UTIL_H

#include <stdio.h>
#include <stdlib.h>
#include "jogo.h"

char *readline(FILE *stream);

#endif